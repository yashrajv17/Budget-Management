import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit  {
  logins: any = {
    "email": "",
    "password": "",
  };
 
  
  constructor(private router:Router ,private http:HttpClient, private authService: AuthService) { }
 
 
  ngOnInit(): void {
  }

  login() {
    this.http.post("http://localhost:5247/api/User/LoginPage", this.logins).subscribe((res: any) => {
      if (res.result) {
        alert("Login Success");
        this.authService.setLoggedIn(true, res.message); 
        this.router.navigate(['/homepage']);
      } else {
        alert(res.message);
      }
    });
  }
}
