import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registers: any = {
    "userId":"",
    "fullName":"",
    "email": "",
    "password": "",
    "confirmPassword":"",
  };
  // email : string ="";
  // password: string="";
  constructor(private router:Router ,private http:HttpClient) { }

  ngOnInit(): void {
  }
  register(){
    this.http.post("http://localhost:5247/api/User/Registration",this.registers).subscribe((res:any)=>{
      if(res.result) {
        alert("Register Success")
        this.router.navigate(['/login']);
      } else {
        alert(res.message)
        console.log(res.message)
      }
    });
  }
}
